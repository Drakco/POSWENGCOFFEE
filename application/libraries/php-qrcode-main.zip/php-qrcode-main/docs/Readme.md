# Auto generated API documentation

The API documentation can be auto generated with [phpDocumentor](https://www.phpdoc.org/). 
There is an [online version available](https://chillerlan.github.io/php-qrcode/) via the [gh-pages branch](https://github.com/chillerlan/php-qrcode/tree/gh-pages) that is [automatically deployed](https://github.com/chillerlan/php-qrcode/deployments) on each push to main.

Locally created docs will appear in this directory. If you'd like to create local docs, please follow these steps:

- [download phpDocumentor](https://github.com/phpDocumentor/phpDocumentor/releases) v3+ as .phar archive
- run it in the repository root directory:
  - on Windows `c:\path\to\php.exe c:\path\to\phpDocumentor.phar --config=phpdoc.xml`
  - on Linux just `php /path/to/phpDocumentor.phar --config=phpdoc.xml`
- open [index.html](./index.html) in a browser
- profit!
